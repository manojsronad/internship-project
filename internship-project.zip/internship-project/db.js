const mysql = require('mysql2');
const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',          // replace with your MySQL user
    password: 'password',          // replace with your MySQL password
    database: 'internship_db'
});
conn.connect((err) => {
    if (err) throw err;
    console.log('✅ MySQL Connected!');
});
module.exports = conn;
