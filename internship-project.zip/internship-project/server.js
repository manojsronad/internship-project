const express = require('express');
const app = express();
const conn = require('./db');
const path = require('path');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.post('/apply', (req, res) => {
    const { name, email, course, domain } = req.body;

    if (!name || !email || !course || !domain) {
        return res.status(400).send('All fields required');
    }

    const query = 'INSERT INTO applications (name, email, course, domain) VALUES (?, ?, ?, ?)';
    conn.query(query, [name, email, course, domain], (err) => {
        if (err) {
            console.error('❌ DB Error:', err.message);
            return res.status(500).send(err.message); // Send full error to browser
        }
        res.status(200).send('Success');
    });
});


app.listen(3000, () => {
    console.log('🚀 Server running on http://localhost:3000');
});
